//
//  methodDemo.h
//  c
//
//  Created by Admin on 26/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface methodDemo : NSObject
-(int) multiplication:(int)num1 withAnotherNumber: (int)num2;

@end
