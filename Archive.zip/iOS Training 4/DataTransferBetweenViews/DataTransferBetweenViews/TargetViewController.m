//
//  TargetViewController.m
//  DataTransferBetweenViews
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "TargetViewController.h"

@interface TargetViewController ()

@end

@implementation TargetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _nameLabel.text=_strName;
    _addressLabel.text=_strAddress;
    _numberLabel.text=_strNumber;
}


@end
