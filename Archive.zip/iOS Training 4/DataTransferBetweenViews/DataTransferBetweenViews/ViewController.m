//
//  ViewController.m
//  DataTransferBetweenViews
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "ViewController.h"
#import "TargetViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


- (IBAction)submitButton:(UIButton *)sender {
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    TargetViewController *tvc;
    tvc=[segue destinationViewController];
    tvc.strName=_textFieldName.text;
    tvc.strAddress=_textFieldAddress.text;
    tvc.strName=_textFieldNumber.text;
}
@end
