//
//  ViewController.h
//  Segue
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

