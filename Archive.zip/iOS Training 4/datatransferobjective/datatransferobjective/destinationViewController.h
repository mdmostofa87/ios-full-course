//
//  destinationViewController.h
//  datatransferobjective
//
//  Created by Admin on 1/11/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface destinationViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *first;
@property (strong, nonatomic) IBOutlet UILabel *second;
@property (strong, nonatomic) IBOutlet UILabel *third;
@property NSString *storex;

@property NSString *storey;

@property NSString *storez;

@end
