//
//  Bank Account.h
//  ClassMethod
//
//  Created by Azad on 13/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Bank_Account : NSObject

+(Bank_Account *)account;

+(int)totalOpen;

@end

