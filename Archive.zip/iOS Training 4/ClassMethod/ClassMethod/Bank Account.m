//
//  Bank Account.m
//  ClassMethod
//
//  Created by Azad on 13/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "Bank Account.h"

@implementation Bank_Account

static int openAccounts = 0;

+(Bank_Account *) account
{
    openAccounts++;
    
    return [Bank_Account alloc];
}

+(int) totalOpen
{
    
    return openAccounts;
}

@end
