//
//  main.m
//  CustomInitializers
//
//  Created by Azad on 28/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Player.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Player *myPlayer=[[Player alloc]init];
        NSLog(@"the score is %i",[myPlayer score]);
        
        Player *myNewPlayer=[[Player alloc]initWithInteger:9999];
        NSLog(@"the score is %i",[myNewPlayer score]);

    }
    return 0;
}
