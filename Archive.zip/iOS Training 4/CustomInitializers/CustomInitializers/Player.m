//
//  Player.m
//  CustomInitializers
//
//  Created by Azad on 28/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import "Player.h"

@implementation Player

//One way to initialize
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        //Custom Code
//        _score=5000;
//    }
//    return self;
//}

//Another Way to initialize when same thing is doing in two methods. the method will recaputulatte with the higher parameter method
-(instancetype)init
{
    self=[self initWithInteger:5000];
    return self;
}

- (instancetype)initWithInteger:(int) initialScore
{
    self = [super init];
    if (self) {
        //Custom Code
        _score=initialScore;
    }
    return self;
}

@end
