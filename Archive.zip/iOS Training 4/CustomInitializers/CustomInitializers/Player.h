//
//  Player.h
//  CustomInitializers
//
//  Created by Azad on 28/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Player : NSObject

@property int score;

-(instancetype)initWithInteger:(int)initialScore;

@end


