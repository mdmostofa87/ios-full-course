//
//  ViewController.m
//  imagegallary
//
//  Created by Admin on 2/11/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _photoItem=[[NSMutableArray alloc]initWithObjects:@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg",@"Unknown.jpg", nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSUInteger)collectionView:(UICollectionView*)collectionView numberOfItemsInSection:(NSInteger)section
{
return _photoItem.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    UICollectionViewCell *myCell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellidentifier" forIndexPath:indexPath];
    UIImageView *cellImage=(UIImageView *) [myCell viewWithTag:1];
    
    cellImage.image=[UIImage imageNamed:[_photoItem objectAtIndex:indexPath.row]];
    
    return myCell;
}

@end
