//
//  Second ViewController.h
//  PassingDataBetweenSegue
//
//  Created by Azad on 12/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Second_ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *LabelView;
@property (strong, nonatomic) NSString *textContent;


@end

NS_ASSUME_NONNULL_END
