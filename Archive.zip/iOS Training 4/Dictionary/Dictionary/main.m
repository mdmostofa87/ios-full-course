//
//  main.m
//  Dictionary
//
//  Created by Azad on 13/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        An empty, immutable dictionary object may be created as follows:
        NSDictionary *bookListing = [NSDictionary dictionary];
        
//        Similarly, an empty mutable dictionary may be created as follows:
        NSMutableDictionary *bookMListing = [NSMutableDictionary dictionary];
        
        
//        Initializing and Adding Entries to a Dictionary Object
//        Each key-value pair contained within a dictionary is referred to as an entry. Once a relationship between a key and a value has been established that relationship cannot subsequently be modified.
//
//        New entries are added to a dictionary using the setObject instance method. This method takes as its arguments an object and a corresponding key:
        
//        NSMutableDictionary *bookMListing = [NSMutableDictionary dictionary];
        
        [bookMListing setObject: @"Wind in the Willows"  forKey: @"100-432112"];
        [bookMListing setObject: @"Tale of Two Cities " forKey:  @"200-532874"];
        [bookMListing setObject: @"Sense and Sensibility" forKey:  @"202-546549"];
        [bookMListing setObject: @"Shutter Island" forKey: @"104-109834"];
        
//        It is also possible to create and initialize a dictionary with a number of key-value pairs using the dictionaryWithObjectsAndKeys class method. For example, an alternative to the above code is as follows:
        NSDictionary *bookListing = [NSDictionary dictionaryWithObjectsAndKeys: @"Wind in the Willows", @"100-432112", @"Tale of Two Cities ", @"200-532874", @"Sense and Sensibility", @"202-546549", @"Shutter Island", @"104-109834", nil];
        
//        Dictionaries may also be initialized using keys and values contained in arrays using the arrayWithObjects method:
        NSArray *objectsArray = [NSArray arrayWithObjects: @"Wind in the Willows", @"Tale of Two Cities ", @"Sense and Sensibility", @"Shutter Island", nil];
        NSArray *keysArray = [NSArray arrayWithObjects: @"100-432112", @"200-532874", @"202-546549", @"104-109834", nil];
        
        NSMutableDictionary *bookListing = [[NSMutableDictionary alloc] initWithObjects: objectsArray forKeys: keysArray];
        
//        Getting an Entry Count
        int count;
        NSLog (@"Number of books in dictionary = %lu", [bookListing count]);
        
//        Accessing Dictionary Entries
//        Dictionary entries are accessed by referencing the key corresponding to the required entry via the objectForKey method. For example:
        NSLog ( @"100-432112 = %@", [bookListing objectForKey: @"100-432112"]);
        NSLog ( @"200-532874 = %@", [bookListing objectForKey: @"200-532874"]);
        NSLog ( @"202-546549 = %@", [bookListing objectForKey: @"202-546549"]);
        NSLog ( @"104-109834 = %@", [bookListing objectForKey: @"104-109834"]);
        
//        Removing Entries from a Dictionary Object
//        Specific dictionary entries may be removed by referencing the key as an argument to the removeObjectForKey method. For example, to remove the book entry for "Shutter Island" we would write the following code:
        [bookListing removeObjectForKey: @"104-109834"];
        
        
//        All entries in a dictionary may be removed using the removeAllObjects instance method:
        [bookListing removeAllObjects];
    }
    return 0;
}
