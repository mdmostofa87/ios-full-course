//
//  TargetViewController.h
//  DataTransfer
//
//  Created by Admin on 12/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TargetViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *nameLabel;
@property (strong, nonatomic) IBOutlet UILabel *addressLabel;
@property (strong, nonatomic) IBOutlet UILabel *numberLabel;

@property (strong, nonatomic) NSString *strNameLabel;
@property (strong, nonatomic) NSString *strAddressLabel;
@property (strong, nonatomic) NSString *strNumberLabel;

@end
