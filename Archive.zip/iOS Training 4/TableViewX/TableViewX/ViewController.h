//
//  ViewController.h
//  TableViewX
//
//  Created by Admin on 17/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>


@end

