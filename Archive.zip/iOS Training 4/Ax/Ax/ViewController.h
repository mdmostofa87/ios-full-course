//
//  ViewController.h
//  Ax
//
//  Created by Admin on 11/9/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)ButtonTapped:(UIButton *)sender;


@end

