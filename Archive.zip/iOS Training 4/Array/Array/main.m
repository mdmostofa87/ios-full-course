//
//  main.m
//  Array
//
//  Created by Azad on 28/8/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        //shorthand Array declaration but this kind of declaration won't possible in NSMutableArray
        NSArray *shortHandArray=@[@"red",@"green",@"yellow"];
        NSLog(@"the short hand array are %@",shortHandArray);
        
        //NSArray can't be changed
        NSArray *myArray=[[NSArray alloc]initWithObjects:@"one",@"two",@"three", nil];
        NSLog(@"The third object is %@",[myArray objectAtIndex:2]);
        
        NSDate *myDate=[[NSDate alloc]init];
        
        //NSMutableArray can be changed
        NSMutableArray *myMutableArray=[[NSMutableArray alloc]initWithObjects:@"cat",@"dog",@"mouse",myDate, nil];
        NSLog(@"The third object is %@",myMutableArray[3]);
        
        //add another string to NSMutableArray
        NSString *anotherString=@"another string";
        [myMutableArray addObject:anotherString];
        NSLog(@"added string is %@",myMutableArray[4]);
        
        //remove a string from NSMutableArray
        [myMutableArray removeObjectAtIndex:0];
        NSLog(@"after removing the first array is %@",myMutableArray[0]);
    }
    return 0;
}
