//
//  Rectangle.h
//  ObjectInitialize
//
//  Created by Azad on 10/9/18.
//  Copyright © 2018 Azad. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface Rectangle : NSObject
@property int height;
@property int width;
@end


