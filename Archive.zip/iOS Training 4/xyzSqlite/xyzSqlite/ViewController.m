//
//  ViewController.m
//  xyzSqlite
//
//  Created by Admin on 30/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize name, address, phone, status;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSString *docsDir;
    NSArray *dirPaths;
    //    get the document directory
    dirPaths=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    docsDir=[dirPaths objectAtIndex:0];
    
    //    Build the path to the database file
    databasePath=[[NSString alloc]initWithString:[docsDir stringByAppendingPathComponent:@"contacts.db"]];
    
    NSFileManager *fileManager=[NSFileManager defaultManager];
    
    if ([fileManager fileExistsAtPath:databasePath] == NO) {
        const char *dbpath=[databasePath UTF8String];
        //        sqlite3_open: This function is used to create and open a database file. It accepts two parameters, where the first one is the database file name, and the second a handler to the database. If the file does not exist, then it creates it first and then it opens it, otherwise it just opens it.
        if (sqlite3_open(dbpath, &contactDB)== SQLITE_OK) {
            char *errMsg;
            const char *sql_stmt="CREATE TABLE IF NOT EXISTS CONTACTS(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT, ADDRESS TEXT, PHONE TEXT)";
            //            that allows an application to run multiple statements of SQL without having to use a lot of C code.
            if (sqlite3_exec(contactDB, sql_stmt, NULL, NULL, &errMsg) != SQLITE_OK) {
                status.text=@"Failed to create table";
            }
            sqlite3_close(contactDB);
        }
        else
        {
            status.text=@"Failed to open/create database";
        }
    }
}


- (IBAction)saveData:(UIButton *)sender {
    sqlite3_stmt *statement;
    const char *dbpath=[databasePath UTF8String];
    if (sqlite3_open(dbpath, &contactDB) ==SQLITE_OK)
    {
        NSString *insertSQL=[NSString stringWithFormat:@"INSERT INTO CONTACTS (name, address, phone) VALUES (\"%@\",\"%@\",\"%@\")",name.text, address.text, phone.text];
        const char *insert_stmt = [insertSQL UTF8String];
        //        sqlite3_prepare_v2: The purpose of this function is to get a SQL statement (a query) in string format, and convert it to an executable format recognizable by SQLite 3.
        sqlite3_prepare_v2(contactDB, insert_stmt, -1, &statement, NULL);
        //        sqlite3_step: This function actually executes a SQL statement (query) prepared with the previous function. It can be called just once for executable queries (insert, update, delete), or multiple times when retrieving data. It’s important to have in mind that it can’t be called prior to the sqlite3_preprare_v2 function.
        if (sqlite3_step(statement) == SQLITE_DONE) {
            status.text=@"Contact added";
            name.text=@"";
            address.text=@"";
            phone.text=@"";
        }
        else
        {
            status.text=@"Failed to add contact";
        }
        //        sqlite3_finalize: It deletes a prepared statement from memory.
        sqlite3_finalize(statement);
        sqlite3_close(contactDB);
    }
}

- (IBAction)findContact:(UIButton *)sender {
    const char *dbpath=[databasePath UTF8String];
    sqlite3_stmt *statement;
    
    if (sqlite3_open(dbpath, &contactDB) == SQLITE_OK) {
        NSString *querySQL = [NSString stringWithFormat:@"SELECT address,phone FROM contacts WHERE name=\"%@\"", name.text];
        const char *query_stmt = [querySQL UTF8String];
        if (sqlite3_prepare_v2(contactDB, query_stmt, -1, &statement, NULL) == SQLITE_OK) {
            if (sqlite3_step(statement)==SQLITE_ROW) {
                NSString *addressField = [[NSString alloc]initWithUTF8String:(const char *) sqlite3_column_text(statement, 0)];
//                sqlite3_column_text: This method returns the contents of a column in text format, actually a C string (char *) value. It accepts two parameters: The first one is the query converted (compiled) to a SQLite statement, and the second one is the index of the column.
                address.text=addressField;
                NSString *phoneField=[[NSString alloc]initWithUTF8String:(const char *) sqlite3_column_text(statement, 1)];
                phone.text=phoneField;
                status.text=@"Match Found";
            }
            else
            {
                status.text=@"Match Not Found";
                address.text=@"";
                phone.text=@"";
            }
            sqlite3_finalize(statement);
        }
        sqlite3_close(contactDB);
    }
}
@end

