//
//  ViewController.h
//  ConstraintDem
//
//  Created by Admin on 19/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

- (IBAction)pressMe:(UIButton *)sender;

@end

