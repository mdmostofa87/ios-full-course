//
//  ViewController.h
//  calnew
//
//  Created by Admin on 19/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (strong, nonatomic) IBOutlet UITextField *text;

- (IBAction)number:(UIButton *)sender;
- (IBAction)plus:(UIButton *)sender;

@end

