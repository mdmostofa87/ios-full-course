//
//  ViewController.h
//  cal
//
//  Created by Admin on 18/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (strong, nonatomic) IBOutlet UITextField *inputText;
@property (strong, nonatomic) IBOutlet UITextField *inputText1;
- (IBAction)plus:(UIButton *)sender;
@property (strong, nonatomic) IBOutlet UILabel *showLabel;

@end

