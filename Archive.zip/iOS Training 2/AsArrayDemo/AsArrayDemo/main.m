//
//  main.m
//  AsArrayDemo
//
//  Created by Admin on 18/10/18.
//  Copyright © 2018 MCC Lab. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        // insert code here...
        NSLog(@"Hello, World!");
        NSString *firstName=@"Mr.";
        NSString *lastName=@"SomeOne";
        int x=35;
        
//        NSArray *myArray=[[NSArray alloc]initwithObjects:firstName,lastName, nij];
        NSArray *myArray=[[NSArray alloc]initWithObjects:firstName,lastName, nil];
        NSLog(@"the array is%@",myArray);
    }
    return 0;
}
NSArray *mySecondArray=[[NSArray,fistName,lastName, nil]];
NSLog(@"the array is %@",myArray);
NSLog(@"the array is %@",mySecondArray;)

[myMutableArray addObject:newObject];
NSLog(@the updated array is %@",myMutableArray);)





