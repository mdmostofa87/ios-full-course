//
//  NSString+CustomStringClass.h
//  catagory
//
//  Created by MacBook Air  on 26/9/18.
//  Copyright © 2018 mahmud. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (CustomStringClass)
-(NSString *) convertWhiteSpace;

@end
