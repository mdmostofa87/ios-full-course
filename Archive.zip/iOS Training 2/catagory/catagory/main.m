//
//  main.m
//  catagory
//
//  Created by MacBook Air  on 26/9/18.
//  Copyright © 2018 mahmud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSString+CustomStringClass.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSString *myString=@"a quick brown fox jumps over a lazy dog.";
        NSLog(@"the converted string is %@", [myString convertWhiteSpace]);
        }
    return 0;
}
